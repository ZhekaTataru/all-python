def make_short(size,text):
    print(f"Вы выбрали футболку, c размером {size} и текстом: {text}")
    for i in text:
        print(f"")
make_short("L", "I love python")
