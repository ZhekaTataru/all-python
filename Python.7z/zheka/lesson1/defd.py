x=int(input("x="))
y=int(input("y="))
c=x+y
z=x-y
v=x/y
b=x*y
print("result", c)
print("result", z)
print("result", v)
print("result", b)
input()
