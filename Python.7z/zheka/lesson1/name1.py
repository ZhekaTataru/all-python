# Hello World program in Python

print ("Hello World!\n")

print (3 ** 5)

# ТЫ можешь писать мат. примеры сразу в "Shell"
