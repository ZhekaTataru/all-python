name=["Мама","Папа","брат","сестра","я"]
print(name)
print(name[2])
print(name[3].title())
print(name[-1])
print(name[-5])

ddd=f"я хочу в мак {name[1]}"



aaa=f"я хочу попить кофе {name[3]}"

name[2] = "Ден"

name.append("Надя")
print(aaa)
