n=int(input("vvedite n -->"))
for i in range(1,n+1):
    print(i**2)
    
