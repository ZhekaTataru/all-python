list =[2,3,5,67,7]
s=0
for i in list:
    list[s]=float(i)
    s+=1
print(list)
