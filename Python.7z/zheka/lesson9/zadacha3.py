k=0
n=int(input("n: "))
for x in range(1,n+1):
    k+=x
    
    print(k)
    
