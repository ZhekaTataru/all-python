kor_int=(10,15,10,10,777,375,15)
a = kor_int.count(10)
print(a)
b = kor_int.count(15)
print(b)
summ=0
for i in kor_int:
    summ+=i
print(summ)
v = sum(kor_int)
print(v)
x = min(kor_int)
print(x)
c = max(kor_int)
print(c)
print("======================")
name={"Denis":24,"Zheka":17,"Vova":15,"Bogdan":17,"Misha":2}
print(name)
p = name["Denis"]
print(p)
a = name["Zheka"]
print(a)
