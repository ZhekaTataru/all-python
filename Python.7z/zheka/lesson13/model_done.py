def gotovo(mass2):
    for i in mass2:
        print(f"{i}-gotov")
