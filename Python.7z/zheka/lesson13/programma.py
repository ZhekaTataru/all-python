mass1=["site1", "site2", "site3", "site4"]
a=mass1[:]
a.insert(2,"site5")
print(mass1)
print(a)
