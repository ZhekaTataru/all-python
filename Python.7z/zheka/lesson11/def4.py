def describe_pet(animal_type, pet_name):
 #Выводит информацию о животном.
  print(f"\nУ меня есть {animal_type}.")
   print(f«Мой {animal_type} и его зовут {pet_name.title()}.")
 
 describe_pet(“хомяк”, “гарри”)
