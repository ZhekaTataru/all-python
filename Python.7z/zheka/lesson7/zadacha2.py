x=int(input("a:"))
a=int(input("x:"))
if x>0:
    if a>0:
        print(a*x)
    else:
        print(2*x*a)
else:
    print(2)
