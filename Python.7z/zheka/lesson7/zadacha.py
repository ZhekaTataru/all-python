import math
print("решим x^2 = a")
a = int(input("vvedite a"))
if a>0:
        print(math.sqrt(a)*(-1), math.sqrt(a))
elif a==0:
        print("x=0")
else:
        print("erorr")
        
    
