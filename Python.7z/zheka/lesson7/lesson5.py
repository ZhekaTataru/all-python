masive = ["zheka", "sasha", "BOGDAN", "zheka","vova"]
print(masive)



print(masive[2])
print(masive[3].title())
print(masive[-1])

print(masive[-5])
      
a=f"Я хочу вывести елемент с названием {masive[3].title()}"
print(a)

b=f"Я хочу в мак с {masive[2].title()}"
print(b)
masive[3]= "Den"
print(masive)
masive.append("suzana")
print(masive)
