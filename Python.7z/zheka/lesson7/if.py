a = int(input("Введите суму -->"))
b = int(input("ведите процент -->"))
c = int(input("ведите количество месяцев -->"))
if c>12:
        s = a+a*(b/100)
        print(s)
else:
        print(a)
        

