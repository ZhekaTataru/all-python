mas = []
mas.append("den")
mas.append("den2")
mas.append("den3")
mas.append("den4")
mas.append("den5")
print(mas)
a=len(mas)
print(mas)
print(a)

