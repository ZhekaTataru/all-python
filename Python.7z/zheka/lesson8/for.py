
#for item in range(13,10,-1):
                    #print(item)


#s=int(input("sum:"))
#p=int(input("proc:"))
#for i in range(5):
    #s+=s*(p/100)
    #print(s)
k=0
a="fdsfdsfsdfd"
for i in a:
    k=k+1
print("количество ", k)

