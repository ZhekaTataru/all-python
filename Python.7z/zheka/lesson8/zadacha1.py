
x=int(input("x:"))
b=int(input("b:"))
if x<=-2:
        if b>0:
              print(3*x**2-8*b)
        else:
            print(-9*x*x-12*b)
else:
    print(32*b+x)                
