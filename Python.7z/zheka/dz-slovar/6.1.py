user={"first_name":"Zheka","last_name":"Tataru","city":"Krivoy Rog"}
print(user["first_name"])
print(user["last_name"])
print(user["city"])
