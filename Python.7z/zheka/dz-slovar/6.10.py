name={"Zhenya":[2,3,6,5,4], 
    "Sasha":[7,11],
    "Den":[5],
    "Zheka":[69,77]
    }
print(name)


