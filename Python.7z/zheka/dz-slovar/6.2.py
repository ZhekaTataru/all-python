name={"Denis":24,"Zheka":17,"Vova":15,"Bogdan":17,"Misha":2}
print(name)
p = name["Denis"]
print(p)
a = name["Zheka"]
print(a)
print(name.items())
