a = int(input("Сумма -"))
p = int(input("Ведите процент --->"))
for b in range(6):
    
    a+=a*(p/100)
    print(a)
