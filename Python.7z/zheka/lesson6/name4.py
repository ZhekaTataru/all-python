for i in range(1):
    i=i+1
    p=1*i
    print(i,p)

for i in range(2):
    i=i+1
    p=2*i
    print(i,p)

for i in range(3):
    i=i+1
    p=3*i
    print(i,p)

for i in range(4):
    i=i+1
    p=4*i
    print(i,p)

for i in range(5):
    i=i+1
    p=5*i
    print(i,p)

for i in range(6):
    i=i+1
    p=6*i
    print(i,p)

for i in range(7):
    i=i+1
    p=7*i
    print(i,p)

for i in range(8):
    i=i+1
    p=8*i
    print(i,p)

for i in range(9):
    i=i+1
    p=9*i
    print(i,p)

for i in range(10):
    i=i+1
    p=10*i
    print(i,p)
