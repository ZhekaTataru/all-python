a = int(input"x"))
b = int(input"b"))
if x<=-2
    else b>0:
        print(3*x**2-8*b)
    else:
        print(-9*x**2-12*b)
elif x>-2:
    print(32*b+x)
else:
    print("error")




