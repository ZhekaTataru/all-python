for i in range(1,11)
for (in range(2,11)
     print (i,t,i*t)
