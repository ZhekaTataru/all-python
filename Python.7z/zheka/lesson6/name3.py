for item in range(2,10,2):
    print(item)
