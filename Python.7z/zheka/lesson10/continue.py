k = 0
while k <= 10:
  k += 1
   if k % 2 == 0:
     continue
   print(“нечетные числа ”, k)
