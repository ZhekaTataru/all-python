#здачача 1(вывод квадратов)

print("y=x^2")


x=int(input("Ведите конечное значение"))
i=1
while i<x:
    y=i**2
    print(i, y)
    i+=1
