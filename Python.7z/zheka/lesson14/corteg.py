dimensions = (200, 50)
print(dimensions)

dimensions = (250, 520, 752)
print(dimensions)
print("================")
dimensions = (200, 50) 
for s in dimensions: 
  print(s)
