alien_0 = {
  'color': 'green', 
  'points': 5
        } 

print(alien_0['color']) 
print(alien_0['points'])
print("====================")
alien_1 = {'color': 'green', 'points': 5}

new_points = alien_1['points'] 
print(f"You just earned {new_points} points!")
