name=input("Как тебя зовут?")
Surname=input("Какая у тебя фамилия")
print("Здраствуй" , Surname , name)
