import random
n=int(input("Количество рядков --> "))
m=int(input("Количество столбцов --> "))
A=[["i"] *m for i in range(n)]
print(A)
for i in A:
    print(i )
