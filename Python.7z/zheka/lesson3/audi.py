mashion=["suzuki","honda","tesla","audi"]
print(mashion)
print(mashion[2].title())
print(mashion[0].title())
print(mashion[1].title())
print(mashion[3].title())
