mashion=["audi","bmv","kia"]
massege= f"Я хочу посмотреть эту марку машины {mashion[2].title()}!"
print(massege)
