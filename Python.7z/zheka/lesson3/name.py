name=[" Лариса"," Саша"," Вова"," Надя"]
name1=f"Приклашаю тебя на свой др{name[0].title()}!"
print(name1)
name2=f"Приклашаю тебя на свой др{name[1].title()}!"
print(name2)
name3=f"Приклашаю тебя на свой др{name[2].title()}!"
print(name3)
name4=f"Приклашаю тебя на свой др{name[3].title()}!"
print(name4)

