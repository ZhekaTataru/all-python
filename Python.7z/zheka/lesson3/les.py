a=int(intup("a="))
b=int(intup("b="))
c=int(intup("c="))
p=(a+b+c)/2
S=math.sqrt(p*(p*a)*(p*b)*(p*c))
print(S)
