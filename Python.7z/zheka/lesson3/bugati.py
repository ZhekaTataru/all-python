mashion=["suzuki","bmv","tesla","audi"]
print(mashion)
mashion[1]="bugati"
print(mashion)
mashion.append("kia")
print(mashion)
