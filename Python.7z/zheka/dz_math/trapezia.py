import math
a=int(input("a="))
b=int(input("b="))
h=int(input("h="))
#d=int(input("d="))
S=(0.5*(a+b)*h)
print("площа = ",S)   
